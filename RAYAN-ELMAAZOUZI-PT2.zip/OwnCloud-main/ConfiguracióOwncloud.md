# Manual de configuració d'OwnCloud

### El primer és anar al OwnCloud iniciar sesió i un cop dintre tens que anar a usuaris pulsant el teu perfil adalt a la dreta, un cop fet tenim que ompli la aquesta fila amb un nombre de usuari i email.

![image](https://github.com/user-attachments/assets/0bbed48f-2f15-4608-808b-1453315c1914)

### Una vegada creada es tindria que apareixer així.

![image](https://github.com/user-attachments/assets/d55bbcc2-7502-4887-8322-bff8069b402c)

### Per poder administra/pujar fitxers teniu que donar-li a la creu i seleccionar el que vulgueu.

![image](https://github.com/user-attachments/assets/98c7a903-a5ad-4ed7-ae35-29533ed54143)

![image](https://github.com/user-attachments/assets/219b772f-a3c5-480b-be30-d5a897a9cfa7) 

### En assiganció de rols i permisos lo que heu de fer és seleccionar "add groups" i alla podeu afegir els rols que vulgueu.
![image](https://github.com/user-attachments/assets/a1de670b-8885-43c0-b965-8b1d67c1f218)

### Per asignar els rols teniu que fer click en "groups" o "admin group for"
![image](https://github.com/user-attachments/assets/a2291002-e98b-44f1-b9f9-e7d765b7653c)

### Finalment, si voleu cambiar el nom o esborrar la foto teniu que seleccionar els tres puntets. 

![image](https://github.com/user-attachments/assets/6980814d-b567-4fc2-81e8-3aeff4270b04)
