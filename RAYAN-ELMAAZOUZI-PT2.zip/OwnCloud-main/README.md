# OwnCloud-Rayan.
Entrega de Uf2 gestor d'arxius web
<!-- [click on this link](#my-multi-word-header) -->

- [Instalació Owncloud](InstalacióOwncloud.md)
- [Configuració Owncloud](ConfiguracióOwncloud.md)

